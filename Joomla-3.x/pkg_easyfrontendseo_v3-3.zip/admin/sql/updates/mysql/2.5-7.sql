ALTER TABLE `#__plg_easyfrontendseo` ADD `id` INT NOT NULL AUTO_INCREMENT FIRST ,
ADD PRIMARY KEY ( `id` ) ,
ADD UNIQUE (
`id`
)